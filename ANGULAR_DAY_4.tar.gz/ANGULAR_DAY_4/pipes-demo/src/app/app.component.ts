import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'pipes-demo';
  todayDate = new Date();
  samplejson = {name: 'Sathish', age:'32', role:'trainer'};
  daysweek=["Monday","Tuesday","Wednesday","Thursday","Friday","Saturday","Sunday"];

}
