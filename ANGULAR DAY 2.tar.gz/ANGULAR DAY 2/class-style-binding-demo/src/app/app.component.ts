import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'class-style-binding-demo';
  fsd = "JavaDeveloper";
  f = document.getElementsByClassName(this.fsd);

  setFSDClassName()
  {
    return "JCD";
  }

  m = document.getElementsByClassName(this.setFSDClassName());

  flag = "false";
}
