import { Directive, ElementRef } from '@angular/core';

@Directive({
  selector: '[custDirectiveTest]'
})
export class SpantextDirective {

  constructor(Element: ElementRef) {
    console.log(Element);
    Element.nativeElement.innerText="Custom Directive Text";
   }

}
